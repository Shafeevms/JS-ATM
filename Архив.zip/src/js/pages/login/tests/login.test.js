// import fetchLogin from './api';

// jest.mock('../../../../__mocks__/loginrequest.js');

// it('Заполняем логин и пароль' () => {
//   expect.assertion(1);
//   return expect(fetchLogin)
// });
