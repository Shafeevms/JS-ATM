// import { fetchLogin } from '../src/js/api';

test('1 + 1 = 2', () => {
  expect(1 + 1).toBe(2);
});
//! не понимаю как создавать мок для этой функции
// test('запрос авторизации на сервис', () => {
//   const correctLogin = { login: 'developer', password: 'skillbox' };
//   expect(fetchLogin(correctLogin)).toBe(
//     {
//       error: '',
//       payload: { token: 'ZGV2ZWxvcGVyOnNraWxsYm94' },
//     }
//   );
// });
