const testForm = new FormData();
testForm.append('key1', 'value1');
testForm.append('key2', 'value2');

export default testForm;
